package com.example.uiview;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        Spinner sp = findViewById(R.id.spCountry);

        String[] country = {
                "India",
                "Bangladesh",
                "Pakistan",
                "Nepal",
                "Sri Lanka"
        };

        ArrayAdapter<String> ad =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_item,
                        country);

        ad.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        sp.setAdapter(ad);

        Button btn = findViewById(R.id.btnSubmit);

        btn.setOnClickListener(v ->
                Toast.makeText(this,
                        "Form Submitted Successfully",
                        Toast.LENGTH_SHORT).show());
    }
}