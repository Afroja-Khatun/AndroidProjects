package com.example.loginmodule;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        EditText user = findViewById(R.id.username);
        EditText pass = findViewById(R.id.password);
        Button login = findViewById(R.id.login);
        TextView result = findViewById(R.id.result);

        login.setOnClickListener(v -> {

            String u = user.getText().toString();
            String p = pass.getText().toString();

            if (u.equals("admin") && p.equals("1234")) {

                result.setText("Login Successful");

            } else {

                Toast.makeText(this,
                        "Login Fail",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}