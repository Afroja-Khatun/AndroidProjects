package com.example.a3uilogin

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val u = findViewById<EditText>(R.id.user)
        val p = findViewById<EditText>(R.id.pass)
        val b = findViewById<Button>(R.id.btn)

        b.setOnClickListener {
            if (u.text.toString() == "afroja" &&
                p.text.toString() == "123456")
                Toast.makeText(this,"Login Successful",Toast.LENGTH_SHORT).show()
            else
                Toast.makeText(this,"Login Failed",Toast.LENGTH_SHORT).show()
        }
    }
}