package com.example.sms;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        EditText phone = findViewById(R.id.phone);
        EditText message = findViewById(R.id.message);
        Button send = findViewById(R.id.send);
        TextView result = findViewById(R.id.result);

        send.setOnClickListener(v -> {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, 1);

            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(
                    phone.getText().toString(),
                    null,
                    message.getText().toString(),
                    null,
                    null
            );

            result.setText("SMS Sent Successfully");
            Toast.makeText(this, "Sent", Toast.LENGTH_SHORT).show();
        });
    }
}