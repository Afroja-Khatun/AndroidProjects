package com.example.menu;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
    }

    public boolean onCreateOptionsMenu(Menu m) {
        getMenuInflater().inflate(R.menu.main_menu, m);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem i) {

        if (i.getItemId() == R.id.about) {
            startActivity(new Intent(this, AboutActivity.class));
        }

        if (i.getItemId() == R.id.contact) {
            startActivity(new Intent(this, ContactActivity.class));
        }

        return true;
    }
}