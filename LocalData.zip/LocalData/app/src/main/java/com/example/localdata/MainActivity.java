package com.example.localdata;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        EditText name = findViewById(R.id.name);
        EditText pass = findViewById(R.id.password);
        Button save = findViewById(R.id.save);
        Button fetch = findViewById(R.id.fetch);
        TextView res = findViewById(R.id.result);

        SharedPreferences sp = getSharedPreferences("MyData", MODE_PRIVATE);

        save.setOnClickListener(v -> {
            sp.edit()
                    .putString("name", name.getText().toString())
                    .putString("pass", pass.getText().toString())
                    .apply();

            res.setText("Saved");
        });

        fetch.setOnClickListener(v -> {
            res.setText(
                    "Name: " + sp.getString("name", "") +
                            "\nPass: " + sp.getString("pass", "")
            );
        });
    }
}