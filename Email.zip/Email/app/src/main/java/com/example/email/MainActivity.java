package com.example.email;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        EditText to = findViewById(R.id.to);
        EditText subject = findViewById(R.id.subject);
        EditText message = findViewById(R.id.message);
        Button send = findViewById(R.id.send);


        send.setOnClickListener(v -> {

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("message/rfc822");

            intent.putExtra(Intent.EXTRA_EMAIL,
                    new String[]{to.getText().toString()});

            intent.putExtra(Intent.EXTRA_SUBJECT,
                    subject.getText().toString());

            intent.putExtra(Intent.EXTRA_TEXT,
                    message.getText().toString());

            startActivity(Intent.createChooser(intent, "Send Email"));
        });
    }
}